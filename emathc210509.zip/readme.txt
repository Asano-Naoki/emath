  サブディレクトリ sty 内にある emath.sty などのファイルを
現在の emath.sty などに上書きします。

lsr を使用している環境では，コマンドプロンプトから
　　　　mktexlsr
を実行する必要があります。


前の訂正版からの主な変更：



emathT.sty v 0.85 2021/03/24
  \SS: \emSS と改名するが，\let\SS\emSS として今までとの互換性をとる(BBS14262）

emathE.sty v 1.18 2021/02/06 
  enumerate: 6重まで許容

EMajmacros.sty v 0.17 2021/02/24
    \ajMaruAlph, \ajKuroMaru: Robust

emath.sty 
		v 2.83 2021/02/06: enumerate: 6重まで許容
    v 2.82 2020.11.29 
        \resetcounter: betaenumerate, yokoenumerate
				環境内の item.. に対しては無効です。 (BBS #14062)

emathGps.sty
		v 0.37 2021/01/28
				\showhistogram: 度数のcsv列を引数に与えることを可能とする。
		v 0.38 2021/02/23
    		\hakohige: meanmark 指定について，yhakohigiG環境の指定を優先する。

emathPh.sty
		v 4.93 2020/02/21
		    \HenKo: henkotype=bracket の場合 yazirusi オプションの処理
		v 4.94 2020/05/27
		    \syaeihasenLG: 射影線のデフォルト値変更
		　　　　　　　　　（特に \syaeihasenLG{} とすることで実線）
		    \DPkukan, \KTkukan 内での \drawXaxis 発行を留保 (BBS #14010
		v 4.95 2020/11/06
		    beamer,tikz,tcolorbox との併用
		v 4.95a 2020/11/08
		    zahyou環境をネストする場合の対応
		v 4.96 2020/11/15
		    \henkomozibox (BBS #14148)
		v 4.97 2021/01/04
				\syaeiP#1: 点#1 の座標軸への射影点を #1x, #1y に保存
		v 4.98 2021/02/21
		    henkotype=vertical

emathPk.sty
	  v 1.54 2020/09/15 \iiLandL バグ修正 (BBS #14097)

pszahyou.sty
		2019/10/27 v 2.41 clipySoukyokusen環境
		2020/04/04 v 2.42 \tenhankei#1: \En<ten=..> における点の大きさ指定
		2020/06/18 v 2.43 \xmemorifunc, \ymemorifunc
		2021/02/15 v 2.44 \xmemoriFunc

emathAe.sty
	  v 0.85 2019/08/02 \setitemoption

emathEy.sty
		v 0.39 2020/11/29 yokoenumerate環境内の \setcurrentenum 使用に対する警告
		　　　　　　　　　(BBS #13952)
		v 0.40 2021/02/06 enumerate:6重まで許容

hako.sty
	  v 1.84 2021/01/13 \dHako: 二重罫線

arhako.sty
		v 1.22 2019/11/21 \brenHako
		v 1.23 2021/01/17 \dHako に対応 (BBS #14224)

EMfbox.sty
		v 0.77 2020/01/24 \emLceil, \emRceil, \emLfloor, \emRfloor
		v 0.78 2020/02/06 \rectbox: shade オプション時，右罫線の横位置修正
		v 0.79 2021/01/14 \EMdblbox: 二重枠

emathPp.sty
		v 1.24 2019/11/28
			\perlRotvec: 収束条件を
			    if(abs($x)<0.0000001){$x=0;}%
				から
		    	if(abs($x)<\emLlim){$x=0;}%
				として，他とそろえる。 (BBS #13903)

emathC.sty
		v 1.20 2020/03/09 \perlteisuuretu: [#1] 書式指定オプション
									（\calcval 互換） (BBS#13987)

emathPsb.sty
		v 0.51 2020/09/01 kokuban: (BBS #14070)

emathPha.sty
		v 0.08α 2020/02/16 \@@@nuritubusi (BBS #13976)

emathR.sty
		v 0.29 2019/08/01 \define@key{emR}{itemoption}{... (BBS #13862)


